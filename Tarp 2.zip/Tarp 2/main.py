import streamlit as st
import numpy as np
import joblib

# Load trained models
crop_model = joblib.load("models/best_crop_recommendation.pkl")
yield_model = joblib.load("models/best_yield_prediction.pkl")
label_encoder = joblib.load("models/labelencoder.pkl")

st.title("🌾 Crop Recommendation & Yield Prediction System")
st.sidebar.header("Choose an Option")

# User selects between Crop Recommendation and Yield Prediction
option = st.sidebar.radio("Select a Feature:", ["Crop Recommendation", "Yield Prediction"])

# Common input fields
st.header("Enter Soil and Climate Conditions")
N = st.number_input("Nitrogen Content (N)", min_value=0, max_value=100, value=50)
P = st.number_input("Phosphorus Content (P)", min_value=0, max_value=100, value=50)
K = st.number_input("Potassium Content (K)", min_value=0, max_value=100, value=50)
temperature = st.number_input("Temperature (°C)", min_value=0.0, max_value=50.0, value=25.0)
humidity = st.number_input("Humidity (%)", min_value=0.0, max_value=100.0, value=60.0)
ph = st.number_input("Soil pH Level", min_value=0.0, max_value=14.0, value=6.5)
rainfall = st.number_input("Rainfall (mm)", min_value=0.0, max_value=500.0, value=200.0)

# Check if an extra feature (like soil_type) is required
soil_type = st.selectbox("Soil Type", ["Sandy", "Clayey", "Loamy", "Peaty", "Saline"])
soil_mapping = {"Sandy": 0, "Clayey": 1, "Loamy": 2, "Peaty": 3, "Saline": 4}
soil_type_encoded = soil_mapping[soil_type]

# Create input array with 8 features
input_data = np.array([[N, P, K, temperature, humidity, ph, rainfall, soil_type_encoded]])

# Crop Recommendation
if option == "Crop Recommendation":
    if st.button("Recommend Crop"):
        crop_index = crop_model.predict(input_data[:, :-1])[0]  # Use only first 7 features
        recommended_crop = label_encoder.inverse_transform([crop_index])[0]
        st.success(f"✅ Recommended Crop: **{recommended_crop}**")

# Crop Yield Prediction
elif option == "Yield Prediction":
    if st.button("Predict Yield"):
        predicted_yield = yield_model.predict(input_data)[0]  # Use all 8 features
        st.success(f"✅ Estimated Crop Yield: **{predicted_yield:.2f} tons per hectare**")
